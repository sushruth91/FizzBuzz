﻿using FizzBuzz.Models;
using FizzBuzz.Services;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace FizzBuzz.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class FizzBuzzController : ControllerBase
    {

        private readonly IFizzBuzz _fizzBuzz; 

        public FizzBuzzController(IFizzBuzz fizzBuzz)
        {
            _fizzBuzz = fizzBuzz;
        }

        [HttpPost("FizzBuzz/GetResult")]
        public List<string> GetResult([FromBody] InputModel model)
        {
            return _fizzBuzz.GetResults(model.Input);
        }
    }
}
