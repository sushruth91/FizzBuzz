﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace FizzBuzz.Services
{
    public interface IFizzBuzz
    {
        public List<string> GetResults(List<string> input);
    }
}
