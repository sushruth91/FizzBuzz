﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace FizzBuzz.Services
{
    public class FizzBuzzService : IFizzBuzz
    {
        public List<string> GetResults(List<string> input)
        {
            List<string> result = new List<string>();
            foreach(string i in input)
            {
                if (Int32.TryParse(i, out int j))
                {
                    if (j % 3 == 0 && j % 5 == 0)
                    {
                        result.Add("FizzBuzz");
                    }
                    else if (j % 3 == 0)
                    {
                        result.Add("Fizz");
                    }
                    else if (j % 5 == 0)
                    {
                        result.Add("Buzz");
                    }
                    else
                    {
                        result.Add("Divided " + j + " by 3");
                        result.Add("Divided " + j + " by 5");
                    }

                }
                else
                {
                    result.Add("Invalid Item");
                }
            }

            return result;
        }
    }
}
